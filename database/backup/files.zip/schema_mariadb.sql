-- ============================================================
--  ESQUEMA MariaDB / MySQL - Sitio de Citas / Directorio
--  Versión: 1.0  |  Engine: InnoDB  |  Charset: utf8mb4
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE DATABASE IF NOT EXISTS sitio_citas
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE sitio_citas;

-- ============================================================
-- 1. ROLES
-- ============================================================

CREATE TABLE roles (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(50)  NOT NULL UNIQUE,
    descripcion TEXT,
    creado_en   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO roles (nombre, descripcion) VALUES
    ('admin',     'Administrador del sistema'),
    ('usuario',   'Usuario registrado'),
    ('perfil',    'Chica con perfil de paga'),
    ('visitante', 'Sin registro, acceso limitado');

-- ============================================================
-- 2. USUARIOS
-- ============================================================

CREATE TABLE usuarios (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    rol_id              INT UNSIGNED NOT NULL,
    username            VARCHAR(60)  NOT NULL UNIQUE,
    email               VARCHAR(191) NOT NULL UNIQUE,
    password_hash       VARCHAR(255) NOT NULL,
    nombre              VARCHAR(100),
    apellido            VARCHAR(100),
    telefono            VARCHAR(30),
    avatar_url          VARCHAR(500),
    activo              TINYINT(1)   NOT NULL DEFAULT 1,
    verificado          TINYINT(1)   NOT NULL DEFAULT 0,
    token_verificacion  VARCHAR(191),
    token_reset         VARCHAR(191),
    token_reset_exp     DATETIME,
    ultimo_login        DATETIME,
    creado_en           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (rol_id) REFERENCES roles(id),
    INDEX idx_email (email),
    INDEX idx_rol   (rol_id)
) ENGINE=InnoDB;

-- ============================================================
-- 3. SESIONES
-- ============================================================

CREATE TABLE sesiones (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    token      VARCHAR(255) NOT NULL UNIQUE,
    ip         VARCHAR(45),
    user_agent TEXT,
    expira_en  DATETIME     NOT NULL,
    creado_en  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_token    (token),
    INDEX idx_usuario  (usuario_id)
) ENGINE=InnoDB;

-- ============================================================
-- 4. CRÉDITOS / TOKENS
-- ============================================================

CREATE TABLE paquetes_creditos (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(100) NOT NULL,
    creditos       INT          NOT NULL,
    precio_usd     DECIMAL(10,2) NOT NULL,
    duracion_dias  INT,
    activo         TINYINT(1)   NOT NULL DEFAULT 1,
    descripcion    TEXT,
    creado_en      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE transacciones (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id       INT UNSIGNED NOT NULL,
    paquete_id       INT UNSIGNED,
    tipo             ENUM('compra','consumo','ajuste','reembolso') NOT NULL,
    creditos         INT          NOT NULL,
    saldo_anterior   INT          NOT NULL,
    saldo_posterior  INT          NOT NULL,
    referencia       VARCHAR(191),
    pasarela         VARCHAR(60),
    estado           ENUM('pendiente','completado','fallido','reembolsado') NOT NULL DEFAULT 'pendiente',
    descripcion      TEXT,
    metadata         JSON,
    creado_en        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (paquete_id) REFERENCES paquetes_creditos(id),
    INDEX idx_trans_usuario (usuario_id)
) ENGINE=InnoDB;

CREATE TABLE saldo_creditos (
    usuario_id     INT UNSIGNED PRIMARY KEY,
    saldo          INT          NOT NULL DEFAULT 0,
    actualizado_en DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Trigger equivalente al de SQLite
DELIMITER $$
CREATE TRIGGER trg_saldo_creditos
    AFTER INSERT ON transacciones
    FOR EACH ROW
BEGIN
    IF NEW.estado = 'completado' THEN
        INSERT INTO saldo_creditos (usuario_id, saldo)
            VALUES (NEW.usuario_id, NEW.saldo_posterior)
        ON DUPLICATE KEY UPDATE
            saldo = NEW.saldo_posterior,
            actualizado_en = CURRENT_TIMESTAMP;
    END IF;
END$$
DELIMITER ;

-- ============================================================
-- 5. UBICACIONES
-- ============================================================

CREATE TABLE paises (
    id     SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    codigo CHAR(3)     NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE regiones (
    id      SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pais_id SMALLINT UNSIGNED NOT NULL,
    nombre  VARCHAR(100) NOT NULL,
    FOREIGN KEY (pais_id) REFERENCES paises(id)
) ENGINE=InnoDB;

CREATE TABLE ciudades (
    id        SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    region_id SMALLINT UNSIGNED NOT NULL,
    nombre    VARCHAR(100) NOT NULL,
    FOREIGN KEY (region_id) REFERENCES regiones(id)
) ENGINE=InnoDB;

-- ============================================================
-- 6. CATEGORÍAS Y ETIQUETAS
-- ============================================================

CREATE TABLE categorias_servicio (
    id        SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre    VARCHAR(100) NOT NULL UNIQUE,
    slug      VARCHAR(120) NOT NULL UNIQUE,
    icono_url VARCHAR(500),
    activo    TINYINT(1)   NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE etiquetas (
    id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(80)  NOT NULL UNIQUE,
    slug   VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ============================================================
-- 7. PERFILES
-- ============================================================

CREATE TABLE perfiles (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id        INT UNSIGNED NOT NULL UNIQUE,
    ciudad_id         SMALLINT UNSIGNED,
    nombre_artistico  VARCHAR(100) NOT NULL,
    slug              VARCHAR(120) NOT NULL UNIQUE,
    bio               TEXT,
    idiomas           JSON,

    -- Datos físicos
    edad              TINYINT UNSIGNED CHECK(edad >= 18),
    altura_cm         SMALLINT UNSIGNED,
    peso_kg           SMALLINT UNSIGNED,
    color_ojos        VARCHAR(30),
    color_cabello     VARCHAR(30),
    complexion        ENUM('delgada','atletica','curvilinea','voluptuosa','otro'),
    busto             VARCHAR(20),
    cadera            VARCHAR(20),
    cintura           VARCHAR(20),

    -- Contacto
    telefono          VARCHAR(30),
    whatsapp          VARCHAR(30),
    telegram          VARCHAR(60),
    instagram         VARCHAR(80),
    twitter_x         VARCHAR(80),
    sitio_web         VARCHAR(255),

    -- Estado
    activo            TINYINT(1)   NOT NULL DEFAULT 0,
    verificado        TINYINT(1)   NOT NULL DEFAULT 0,
    destacado         TINYINT(1)   NOT NULL DEFAULT 0,
    estado_moderacion ENUM('pendiente','aprobado','rechazado','suspendido') NOT NULL DEFAULT 'pendiente',
    razon_rechazo     TEXT,
    foto_portada_id   INT UNSIGNED,
    vistas            INT UNSIGNED NOT NULL DEFAULT 0,
    creditos_gastados INT UNSIGNED NOT NULL DEFAULT 0,

    creado_en         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (ciudad_id)  REFERENCES ciudades(id),
    INDEX idx_ciudad  (ciudad_id),
    INDEX idx_activo  (activo),
    INDEX idx_slug    (slug)
) ENGINE=InnoDB;

CREATE TABLE perfil_categorias (
    perfil_id    INT UNSIGNED     NOT NULL,
    categoria_id SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (perfil_id, categoria_id),
    FOREIGN KEY (perfil_id)    REFERENCES perfiles(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias_servicio(id)
) ENGINE=InnoDB;

CREATE TABLE perfil_etiquetas (
    perfil_id   INT UNSIGNED NOT NULL,
    etiqueta_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (perfil_id, etiqueta_id),
    FOREIGN KEY (perfil_id)   REFERENCES perfiles(id) ON DELETE CASCADE,
    FOREIGN KEY (etiqueta_id) REFERENCES etiquetas(id)
) ENGINE=InnoDB;

CREATE TABLE disponibilidad (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    perfil_id   INT UNSIGNED NOT NULL,
    dia_semana  TINYINT UNSIGNED NOT NULL CHECK(dia_semana BETWEEN 0 AND 6),
    hora_inicio TIME NOT NULL,
    hora_fin    TIME NOT NULL,
    FOREIGN KEY (perfil_id) REFERENCES perfiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 8. MEDIA
-- ============================================================

CREATE TABLE media (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    perfil_id         INT UNSIGNED NOT NULL,
    tipo              ENUM('foto','video') NOT NULL,
    url               VARCHAR(500) NOT NULL,
    url_miniatura     VARCHAR(500),
    titulo            VARCHAR(200),
    descripcion       TEXT,
    es_publica        TINYINT(1)   NOT NULL DEFAULT 1,
    es_portada        TINYINT(1)   NOT NULL DEFAULT 0,
    orden             SMALLINT     NOT NULL DEFAULT 0,
    duracion_seg      INT UNSIGNED,
    tamanio_bytes     BIGINT UNSIGNED,
    ancho_px          SMALLINT UNSIGNED,
    alto_px           SMALLINT UNSIGNED,
    estado_moderacion ENUM('pendiente','aprobado','rechazado') NOT NULL DEFAULT 'pendiente',
    moderado_por      INT UNSIGNED,
    moderado_en       DATETIME,
    razon_rechazo     TEXT,
    creado_en         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (perfil_id)    REFERENCES perfiles(id) ON DELETE CASCADE,
    FOREIGN KEY (moderado_por) REFERENCES usuarios(id),
    INDEX idx_perfil (perfil_id),
    INDEX idx_estado (estado_moderacion)
) ENGINE=InnoDB;

-- FK circular perfiles ↔ media (foto_portada_id)
ALTER TABLE perfiles
    ADD CONSTRAINT fk_portada FOREIGN KEY (foto_portada_id) REFERENCES media(id) ON DELETE SET NULL;

-- ============================================================
-- 9. LIKES Y FAVORITOS
-- ============================================================

CREATE TABLE likes (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    perfil_id  INT UNSIGNED NOT NULL,
    creado_en  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_like (usuario_id, perfil_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (perfil_id)  REFERENCES perfiles(id) ON DELETE CASCADE,
    INDEX idx_perfil  (perfil_id),
    INDEX idx_usuario (usuario_id)
) ENGINE=InnoDB;

CREATE TABLE favoritos (
    usuario_id INT UNSIGNED NOT NULL,
    perfil_id  INT UNSIGNED NOT NULL,
    creado_en  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (usuario_id, perfil_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (perfil_id)  REFERENCES perfiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 10. COMENTARIOS
-- ============================================================

CREATE TABLE comentarios (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    perfil_id    INT UNSIGNED NOT NULL,
    usuario_id   INT UNSIGNED NOT NULL,
    padre_id     INT UNSIGNED,
    contenido    TEXT         NOT NULL,
    estado       ENUM('pendiente','aprobado','rechazado','spam') NOT NULL DEFAULT 'pendiente',
    moderado_por INT UNSIGNED,
    moderado_en  DATETIME,
    creado_en    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (perfil_id)    REFERENCES perfiles(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id)   REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (padre_id)     REFERENCES comentarios(id) ON DELETE CASCADE,
    FOREIGN KEY (moderado_por) REFERENCES usuarios(id),
    INDEX idx_perfil  (perfil_id),
    INDEX idx_usuario (usuario_id)
) ENGINE=InnoDB;

-- ============================================================
-- 11. VALORACIONES
-- ============================================================

CREATE TABLE valoraciones (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    perfil_id  INT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    puntuacion TINYINT UNSIGNED NOT NULL CHECK(puntuacion BETWEEN 1 AND 5),
    resena     TEXT,
    creado_en  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_val (usuario_id, perfil_id),
    FOREIGN KEY (perfil_id)  REFERENCES perfiles(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_perfil (perfil_id)
) ENGINE=InnoDB;

CREATE VIEW v_promedio_valoraciones AS
SELECT
    perfil_id,
    COUNT(*)                   AS total_valoraciones,
    ROUND(AVG(puntuacion), 2)  AS promedio,
    SUM(puntuacion = 5)        AS cinco_estrellas,
    SUM(puntuacion = 4)        AS cuatro_estrellas,
    SUM(puntuacion = 3)        AS tres_estrellas,
    SUM(puntuacion = 2)        AS dos_estrellas,
    SUM(puntuacion = 1)        AS una_estrella
FROM valoraciones
GROUP BY perfil_id;

-- ============================================================
-- 12. MENSAJES PRIVADOS
-- ============================================================

CREATE TABLE conversaciones (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id   INT UNSIGNED NOT NULL,
    perfil_id    INT UNSIGNED NOT NULL,
    ultimo_msg_en DATETIME,
    creado_en    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_conv (usuario_id, perfil_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (perfil_id)  REFERENCES perfiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE mensajes (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversacion_id  INT UNSIGNED NOT NULL,
    remitente_id     INT UNSIGNED NOT NULL,
    contenido        TEXT         NOT NULL,
    leido            TINYINT(1)   NOT NULL DEFAULT 0,
    leido_en         DATETIME,
    creado_en        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversacion_id) REFERENCES conversaciones(id) ON DELETE CASCADE,
    FOREIGN KEY (remitente_id)    REFERENCES usuarios(id),
    INDEX idx_conv (conversacion_id)
) ENGINE=InnoDB;

-- ============================================================
-- 13. PLANES DE VISIBILIDAD Y SUSCRIPCIONES
-- ============================================================

CREATE TABLE planes_visibilidad (
    id             TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(80)   NOT NULL,
    creditos_dia   SMALLINT      NOT NULL,
    beneficios     JSON,
    activo         TINYINT(1)    NOT NULL DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO planes_visibilidad (nombre, creditos_dia, beneficios) VALUES
    ('Perfil Básico',    5,  '{"destacado":false,"top":false,"fotos_extra":0}'),
    ('Perfil Destacado', 15, '{"destacado":true,"top":false,"fotos_extra":5}'),
    ('Perfil Top',       30, '{"destacado":true,"top":true,"fotos_extra":20}');

CREATE TABLE suscripciones_visibilidad (
    id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    perfil_id INT UNSIGNED    NOT NULL,
    plan_id   TINYINT UNSIGNED NOT NULL,
    activa    TINYINT(1)      NOT NULL DEFAULT 1,
    inicio_en DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fin_en    DATETIME,
    creado_en DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (perfil_id) REFERENCES perfiles(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id)   REFERENCES planes_visibilidad(id)
) ENGINE=InnoDB;

-- ============================================================
-- 14. REPORTES Y LOG DE MODERACIÓN
-- ============================================================

CREATE TABLE reportes (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    reportado_por INT UNSIGNED NOT NULL,
    tipo_objeto   ENUM('perfil','media','comentario','usuario') NOT NULL,
    objeto_id     INT UNSIGNED NOT NULL,
    motivo        ENUM('spam','contenido_falso','menor_edad','acoso','otro') NOT NULL,
    descripcion   TEXT,
    estado        ENUM('pendiente','revisado','resuelto','descartado') NOT NULL DEFAULT 'pendiente',
    revisado_por  INT UNSIGNED,
    revisado_en   DATETIME,
    creado_en     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reportado_por) REFERENCES usuarios(id),
    FOREIGN KEY (revisado_por)  REFERENCES usuarios(id)
) ENGINE=InnoDB;

CREATE TABLE log_moderacion (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_id    INT UNSIGNED NOT NULL,
    tipo_objeto VARCHAR(30)  NOT NULL,
    objeto_id   INT UNSIGNED NOT NULL,
    accion      VARCHAR(30)  NOT NULL,
    nota        TEXT,
    creado_en   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES usuarios(id)
) ENGINE=InnoDB;

-- ============================================================
-- 15. NOTIFICACIONES
-- ============================================================

CREATE TABLE notificaciones (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id  INT UNSIGNED NOT NULL,
    tipo        VARCHAR(60)  NOT NULL,
    titulo      VARCHAR(200) NOT NULL,
    cuerpo      TEXT,
    leida       TINYINT(1)   NOT NULL DEFAULT 0,
    url_accion  VARCHAR(500),
    creado_en   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario (usuario_id)
) ENGINE=InnoDB;

-- ============================================================
-- 16. CONFIGURACIÓN
-- ============================================================

CREATE TABLE configuracion (
    clave          VARCHAR(80)  PRIMARY KEY,
    valor          TEXT         NOT NULL,
    descripcion    TEXT,
    actualizado_en DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO configuracion (clave, valor, descripcion) VALUES
    ('site_name',             'MiSitio', 'Nombre del sitio'),
    ('creditos_alerta_baja',  '10',      'Alerta cuando saldo baje de este valor'),
    ('max_fotos_basico',      '10',      'Máximo fotos plan básico'),
    ('max_videos_basico',     '2',       'Máximo videos plan básico'),
    ('moderacion_automatica', '0',       '1=publicar directo si pasa filtro IA'),
    ('edad_minima',           '18',      'Edad mínima para perfil');

-- ============================================================
-- FIN DEL ESQUEMA MariaDB/MySQL
-- ============================================================
