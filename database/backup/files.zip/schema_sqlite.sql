-- ============================================================
--  ESQUEMA SQLite - Sitio de Citas / Directorio de Perfiles
--  Compatible con migración futura a MariaDB / MySQL
--  Versión: 1.0
-- ============================================================

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- ============================================================
-- 1. ROLES Y TIPOS DE USUARIO
-- ============================================================

CREATE TABLE roles (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre      TEXT    NOT NULL UNIQUE,   -- 'admin','usuario','perfil','visitante'
    descripcion TEXT,
    creado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

INSERT INTO roles (nombre, descripcion) VALUES
    ('admin',     'Administrador del sistema'),
    ('usuario',   'Usuario registrado (puede ver perfiles, comentar, dar likes)'),
    ('perfil',    'Chica con perfil de paga'),
    ('visitante', 'Sin registro, acceso limitado');

-- ============================================================
-- 2. USUARIOS (tabla central)
-- ============================================================

CREATE TABLE usuarios (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    rol_id           INTEGER NOT NULL REFERENCES roles(id),
    username         TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    email            TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    password_hash    TEXT    NOT NULL,
    nombre           TEXT,
    apellido         TEXT,
    telefono         TEXT,
    avatar_url       TEXT,
    activo           INTEGER NOT NULL DEFAULT 1,          -- 0=baneado, 1=activo
    verificado       INTEGER NOT NULL DEFAULT 0,          -- email verificado
    token_verificacion TEXT,
    token_reset      TEXT,
    token_reset_exp  TEXT,
    ultimo_login     TEXT,
    creado_en        TEXT    NOT NULL DEFAULT (datetime('now')),
    actualizado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_usuarios_email  ON usuarios(email);
CREATE INDEX idx_usuarios_rol    ON usuarios(rol_id);

-- ============================================================
-- 3. SESIONES / TOKENS DE ACCESO
-- ============================================================

CREATE TABLE sesiones (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    token       TEXT    NOT NULL UNIQUE,
    ip          TEXT,
    user_agent  TEXT,
    expira_en   TEXT    NOT NULL,
    creado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_sesiones_token      ON sesiones(token);
CREATE INDEX idx_sesiones_usuario    ON sesiones(usuario_id);

-- ============================================================
-- 4. CRÉDITOS / TOKENS (sistema de pago)
-- ============================================================

CREATE TABLE paquetes_creditos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre      TEXT    NOT NULL,          -- 'Básico', 'Premium', 'VIP'
    creditos    INTEGER NOT NULL,          -- cantidad de créditos que otorga
    precio_usd  REAL    NOT NULL,
    duracion_dias INTEGER,                 -- NULL = sin vencimiento
    activo      INTEGER NOT NULL DEFAULT 1,
    descripcion TEXT,
    creado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE transacciones (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id       INTEGER NOT NULL REFERENCES usuarios(id),
    paquete_id       INTEGER REFERENCES paquetes_creditos(id),
    tipo             TEXT    NOT NULL CHECK(tipo IN ('compra','consumo','ajuste','reembolso')),
    creditos         INTEGER NOT NULL,     -- positivo=entrada, negativo=salida
    saldo_anterior   INTEGER NOT NULL,
    saldo_posterior  INTEGER NOT NULL,
    referencia       TEXT,                 -- ID externo de pasarela de pago
    pasarela         TEXT,                 -- 'stripe','paypal','mercadopago', etc.
    estado           TEXT    NOT NULL DEFAULT 'pendiente'
                             CHECK(estado IN ('pendiente','completado','fallido','reembolsado')),
    descripcion      TEXT,
    metadata         TEXT,                 -- JSON extra (respuesta pasarela, etc.)
    creado_en        TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_trans_usuario ON transacciones(usuario_id);

CREATE TABLE saldo_creditos (
    usuario_id  INTEGER PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
    saldo       INTEGER NOT NULL DEFAULT 0,
    actualizado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================
-- 5. UBICACIONES (catálogo geográfico)
-- ============================================================

CREATE TABLE paises (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT    NOT NULL UNIQUE,   -- 'CL', 'AR', 'MX'
    nombre TEXT    NOT NULL
);

CREATE TABLE regiones (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    pais_id  INTEGER NOT NULL REFERENCES paises(id),
    nombre   TEXT    NOT NULL
);

CREATE TABLE ciudades (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    region_id  INTEGER NOT NULL REFERENCES regiones(id),
    nombre     TEXT    NOT NULL
);

-- ============================================================
-- 6. CATEGORÍAS Y ETIQUETAS DE SERVICIOS
-- ============================================================

CREATE TABLE categorias_servicio (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre    TEXT    NOT NULL UNIQUE,
    slug      TEXT    NOT NULL UNIQUE,
    icono_url TEXT,
    activo    INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE etiquetas (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE COLLATE NOCASE,
    slug   TEXT NOT NULL UNIQUE
);

-- ============================================================
-- 7. PERFILES DE CHICAS
-- ============================================================

CREATE TABLE perfiles (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id       INTEGER NOT NULL UNIQUE REFERENCES usuarios(id) ON DELETE CASCADE,
    ciudad_id        INTEGER REFERENCES ciudades(id),

    -- Identidad pública
    nombre_artistico TEXT    NOT NULL,
    slug             TEXT    NOT NULL UNIQUE,     -- para URL amigable
    bio              TEXT,
    idiomas          TEXT,                        -- JSON array: ["es","en"]

    -- Datos físicos
    edad             INTEGER CHECK(edad >= 18),
    altura_cm        INTEGER,
    peso_kg          INTEGER,
    color_ojos       TEXT,
    color_cabello    TEXT,
    complexion       TEXT,    -- 'delgada','atletica','curvilínea','voluptuosa'
    busto            TEXT,
    cadera           TEXT,
    cintura          TEXT,

    -- Contacto y redes (visibles solo si tiene saldo activo)
    telefono         TEXT,
    whatsapp         TEXT,
    telegram         TEXT,
    instagram        TEXT,
    twitter_x        TEXT,
    sitio_web        TEXT,

    -- Estado del perfil
    activo           INTEGER NOT NULL DEFAULT 0,  -- activado cuando tiene créditos
    verificado       INTEGER NOT NULL DEFAULT 0,  -- verificado por admin
    destacado        INTEGER NOT NULL DEFAULT 0,  -- perfil destacado (más créditos)
    estado_moderacion TEXT NOT NULL DEFAULT 'pendiente'
                          CHECK(estado_moderacion IN ('pendiente','aprobado','rechazado','suspendido')),
    razon_rechazo    TEXT,

    -- Visibilidad
    foto_portada_id  INTEGER,                     -- FK se agrega después (ver abajo)
    vistas           INTEGER NOT NULL DEFAULT 0,
    creditos_gastados INTEGER NOT NULL DEFAULT 0,

    creado_en        TEXT    NOT NULL DEFAULT (datetime('now')),
    actualizado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_perfiles_ciudad   ON perfiles(ciudad_id);
CREATE INDEX idx_perfiles_activo   ON perfiles(activo);
CREATE INDEX idx_perfiles_slug     ON perfiles(slug);

-- Relación perfil ↔ categorías de servicio
CREATE TABLE perfil_categorias (
    perfil_id    INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    categoria_id INTEGER NOT NULL REFERENCES categorias_servicio(id),
    PRIMARY KEY (perfil_id, categoria_id)
);

-- Relación perfil ↔ etiquetas
CREATE TABLE perfil_etiquetas (
    perfil_id  INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    etiqueta_id INTEGER NOT NULL REFERENCES etiquetas(id),
    PRIMARY KEY (perfil_id, etiqueta_id)
);

-- Horarios de disponibilidad
CREATE TABLE disponibilidad (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    perfil_id   INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    dia_semana  INTEGER NOT NULL CHECK(dia_semana BETWEEN 0 AND 6), -- 0=Dom, 6=Sáb
    hora_inicio TEXT    NOT NULL,  -- 'HH:MM'
    hora_fin    TEXT    NOT NULL
);

-- ============================================================
-- 8. MEDIA (FOTOS Y VIDEOS)
-- ============================================================

CREATE TABLE media (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    perfil_id        INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    tipo             TEXT    NOT NULL CHECK(tipo IN ('foto','video')),
    url              TEXT    NOT NULL,
    url_miniatura    TEXT,
    titulo           TEXT,
    descripcion      TEXT,
    es_publica       INTEGER NOT NULL DEFAULT 1,  -- 0 = solo con créditos
    es_portada       INTEGER NOT NULL DEFAULT 0,
    orden            INTEGER NOT NULL DEFAULT 0,
    duracion_seg     INTEGER,                     -- solo para videos
    tamanio_bytes    INTEGER,
    ancho_px         INTEGER,
    alto_px          INTEGER,

    -- Moderación
    estado_moderacion TEXT NOT NULL DEFAULT 'pendiente'
                          CHECK(estado_moderacion IN ('pendiente','aprobado','rechazado')),
    moderado_por     INTEGER REFERENCES usuarios(id),
    moderado_en      TEXT,
    razon_rechazo    TEXT,

    creado_en        TEXT    NOT NULL DEFAULT (datetime('now')),
    actualizado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_media_perfil  ON media(perfil_id);
CREATE INDEX idx_media_estado  ON media(estado_moderacion);

-- Ahora que media existe, podemos agregar la FK de foto_portada
-- (En SQLite no se puede ALTER TABLE ADD CONSTRAINT; se maneja por lógica de app)
-- En MariaDB/MySQL sería: ALTER TABLE perfiles ADD CONSTRAINT fk_portada FOREIGN KEY (foto_portada_id) REFERENCES media(id);

-- ============================================================
-- 9. LIKES / FAVORITOS
-- ============================================================

CREATE TABLE likes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    perfil_id   INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    creado_en   TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE (usuario_id, perfil_id)
);

CREATE INDEX idx_likes_perfil   ON likes(perfil_id);
CREATE INDEX idx_likes_usuario  ON likes(usuario_id);

-- Favoritos (bookmark, distinto de like)
CREATE TABLE favoritos (
    usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    perfil_id   INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    creado_en   TEXT    NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (usuario_id, perfil_id)
);

-- ============================================================
-- 10. COMENTARIOS
-- ============================================================

CREATE TABLE comentarios (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    perfil_id   INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    padre_id    INTEGER REFERENCES comentarios(id) ON DELETE CASCADE,  -- respuestas
    contenido   TEXT    NOT NULL,
    estado      TEXT    NOT NULL DEFAULT 'pendiente'
                        CHECK(estado IN ('pendiente','aprobado','rechazado','spam')),
    moderado_por INTEGER REFERENCES usuarios(id),
    moderado_en  TEXT,
    creado_en   TEXT    NOT NULL DEFAULT (datetime('now')),
    actualizado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_comentarios_perfil  ON comentarios(perfil_id);
CREATE INDEX idx_comentarios_usuario ON comentarios(usuario_id);

-- ============================================================
-- 11. VALORACIONES (ESTRELLAS)
-- ============================================================

CREATE TABLE valoraciones (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    perfil_id   INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    puntuacion  INTEGER NOT NULL CHECK(puntuacion BETWEEN 1 AND 5),
    resena      TEXT,
    creado_en   TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE (usuario_id, perfil_id)
);

CREATE INDEX idx_val_perfil ON valoraciones(perfil_id);

-- Vista materializable: promedio de valoraciones por perfil
CREATE VIEW v_promedio_valoraciones AS
SELECT
    perfil_id,
    COUNT(*)            AS total_valoraciones,
    ROUND(AVG(puntuacion), 2) AS promedio,
    SUM(CASE WHEN puntuacion = 5 THEN 1 ELSE 0 END) AS cinco_estrellas,
    SUM(CASE WHEN puntuacion = 4 THEN 1 ELSE 0 END) AS cuatro_estrellas,
    SUM(CASE WHEN puntuacion = 3 THEN 1 ELSE 0 END) AS tres_estrellas,
    SUM(CASE WHEN puntuacion = 2 THEN 1 ELSE 0 END) AS dos_estrellas,
    SUM(CASE WHEN puntuacion = 1 THEN 1 ELSE 0 END) AS una_estrella
FROM valoraciones
GROUP BY perfil_id;

-- ============================================================
-- 12. MENSAJES PRIVADOS (entre usuarios registrados y perfiles)
-- ============================================================

CREATE TABLE conversaciones (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id   INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    perfil_id    INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    ultimo_msg_en TEXT,
    creado_en    TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE (usuario_id, perfil_id)
);

CREATE TABLE mensajes (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    conversacion_id  INTEGER NOT NULL REFERENCES conversaciones(id) ON DELETE CASCADE,
    remitente_id     INTEGER NOT NULL REFERENCES usuarios(id),
    contenido        TEXT    NOT NULL,
    leido            INTEGER NOT NULL DEFAULT 0,
    leido_en         TEXT,
    creado_en        TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_mensajes_conv ON mensajes(conversacion_id);

-- ============================================================
-- 13. CONSUMO DE CRÉDITOS POR VISIBILIDAD
-- ============================================================

CREATE TABLE planes_visibilidad (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre         TEXT    NOT NULL,    -- 'Perfil Activo', 'Destacado', 'Top'
    creditos_dia   INTEGER NOT NULL,    -- créditos consumidos por día
    beneficios     TEXT,               -- JSON: {"destacado":true, "top":false}
    activo         INTEGER NOT NULL DEFAULT 1
);

INSERT INTO planes_visibilidad (nombre, creditos_dia, beneficios) VALUES
    ('Perfil Básico',    5,  '{"destacado":false,"top":false,"fotos_extra":0}'),
    ('Perfil Destacado', 15, '{"destacado":true,"top":false,"fotos_extra":5}'),
    ('Perfil Top',       30, '{"destacado":true,"top":true,"fotos_extra":20}');

CREATE TABLE suscripciones_visibilidad (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    perfil_id        INTEGER NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
    plan_id          INTEGER NOT NULL REFERENCES planes_visibilidad(id),
    activa           INTEGER NOT NULL DEFAULT 1,
    inicio_en        TEXT    NOT NULL DEFAULT (datetime('now')),
    fin_en           TEXT,             -- NULL = se renueva diariamente mientras haya saldo
    creado_en        TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================
-- 14. MODERACIÓN Y REPORTES
-- ============================================================

CREATE TABLE reportes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    reportado_por INTEGER NOT NULL REFERENCES usuarios(id),
    tipo_objeto  TEXT    NOT NULL CHECK(tipo_objeto IN ('perfil','media','comentario','usuario')),
    objeto_id    INTEGER NOT NULL,
    motivo       TEXT    NOT NULL CHECK(motivo IN ('spam','contenido_falso','menor_edad','acoso','otro')),
    descripcion  TEXT,
    estado       TEXT    NOT NULL DEFAULT 'pendiente'
                         CHECK(estado IN ('pendiente','revisado','resuelto','descartado')),
    revisado_por INTEGER REFERENCES usuarios(id),
    revisado_en  TEXT,
    creado_en    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE log_moderacion (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id     INTEGER NOT NULL REFERENCES usuarios(id),
    tipo_objeto  TEXT    NOT NULL,
    objeto_id    INTEGER NOT NULL,
    accion       TEXT    NOT NULL,   -- 'aprobar','rechazar','suspender','restaurar'
    nota         TEXT,
    creado_en    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================
-- 15. NOTIFICACIONES
-- ============================================================

CREATE TABLE notificaciones (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id   INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    tipo         TEXT    NOT NULL,  -- 'like','comentario','nuevo_mensaje','credito_bajo', etc.
    titulo       TEXT    NOT NULL,
    cuerpo       TEXT,
    leida        INTEGER NOT NULL DEFAULT 0,
    url_accion   TEXT,
    creado_en    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_notif_usuario ON notificaciones(usuario_id);

-- ============================================================
-- 16. CONFIGURACIÓN DEL SISTEMA
-- ============================================================

CREATE TABLE configuracion (
    clave       TEXT PRIMARY KEY,
    valor       TEXT NOT NULL,
    descripcion TEXT,
    actualizado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT INTO configuracion (clave, valor, descripcion) VALUES
    ('site_name',             'MiSitio',  'Nombre del sitio'),
    ('creditos_alerta_baja',  '10',       'Notificar cuando el saldo baje de este valor'),
    ('max_fotos_basico',      '10',       'Máximo de fotos en plan básico'),
    ('max_videos_basico',     '2',        'Máximo de videos en plan básico'),
    ('moderacion_automatica', '0',        '1=publicar directo si pasa filtro IA'),
    ('edad_minima',           '18',       'Edad mínima para registrar perfil');

-- ============================================================
-- TRIGGERS: mantener updated_at automáticamente
-- ============================================================

CREATE TRIGGER trg_usuarios_upd
    AFTER UPDATE ON usuarios
BEGIN
    UPDATE usuarios SET actualizado_en = datetime('now') WHERE id = NEW.id;
END;

CREATE TRIGGER trg_perfiles_upd
    AFTER UPDATE ON perfiles
BEGIN
    UPDATE perfiles SET actualizado_en = datetime('now') WHERE id = NEW.id;
END;

CREATE TRIGGER trg_media_upd
    AFTER UPDATE ON media
BEGIN
    UPDATE media SET actualizado_en = datetime('now') WHERE id = NEW.id;
END;

-- Mantener saldo_creditos consistente en cada transacción completada
CREATE TRIGGER trg_saldo_creditos
    AFTER INSERT ON transacciones
    WHEN NEW.estado = 'completado'
BEGIN
    INSERT INTO saldo_creditos (usuario_id, saldo, actualizado_en)
        VALUES (NEW.usuario_id, NEW.saldo_posterior, datetime('now'))
    ON CONFLICT(usuario_id) DO UPDATE
        SET saldo = NEW.saldo_posterior,
            actualizado_en = datetime('now');
END;

-- ============================================================
-- FIN DEL ESQUEMA
-- ============================================================
